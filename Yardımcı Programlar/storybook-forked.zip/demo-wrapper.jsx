import * as React from "react";

const DemoWrapper = ({ children }) => {
  return <div className="demo-wrapper">{children}</div>;
};

export default DemoWrapper;
