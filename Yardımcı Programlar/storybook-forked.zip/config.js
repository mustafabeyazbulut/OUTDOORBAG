const { join } = require("path");

module.exports = {
  ksPublic: join(__dirname, "ks-public/"),
  ksPublicDist: join(__dirname, "ks-public/dist/")
};
